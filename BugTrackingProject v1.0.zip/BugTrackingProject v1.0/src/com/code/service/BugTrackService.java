//Author : Akanksha Shrivastava, Adrija Ghansiyal, Abhijeet Nitin Raut
//Purpose : Interface for business logic layer (service layer)

package com.code.service;

import java.util.List;

import com.code.bean.Bug;
import com.code.bean.Project;
import com.code.bean.User;

public interface BugTrackService {

	//Method to call dao layer and save imported users into db
		int importUsers(List<User> userList);
		
	//Method to get the list of all projects acc. to user ID
	List<Project> getAllProjects(int userid);
	
	//Method to get the list of bugs acc. to user ID and project ID
	List<Bug> getAllBugs(List<Project> projectList);
	
	//Method to get all free employees
	List<User> getAllEmployees();
	
	//To add a new project
	boolean addProject(Project p);
	
	//To update the number of projects under a user
	void updateNoOfProjects(int[] userIdChecked);
	
	//To users to Team
	void addToTeam(int projectId,int[] userIdChecked);
	
}
