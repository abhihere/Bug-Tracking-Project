package com.code.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class AddProject
 */
@WebServlet("/addproject")
public class AddProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String role=(String) session.getAttribute("role");
		if((role.toLowerCase()).equals("project manager")) {
			int managerid=Integer.parseInt(request.getParameter("managerid"));
			int projectId=Integer.parseInt(request.getParameter("projectId"));
			String projectName=request.getParameter("projectName");
			String date=request.getParameter("startDate");
			String description=request.getParameter("description");
			String status=	"in progress";
			int [] userIdChecked = request.getParameterValues("User");
		
			Project project=new Project(projectId,projectName,description,date,status,managerid);
			BugTrackService bugTrackService=new BugTrackServiceImpl();
			bugTrackService.updateNoOfProjects(userIdChecked);
			bugTrackService.addToTeam(projectId,userIdChecked);
			boolean flag=bugTrackService.addproject(project);
			if(flag) {
				out.println("Project successfully added");
				RequestDispatcher rd=request.getRequestDispatcher("PMlogin.jsp");
				rd.include(request, response);
			}
			else {
				out.println("Project not added");
				RequestDispatcher rd=request.getRequestDispatcher("PMlogin.jsp");
				rd.include(request, response);
				
			}
			
			
		}
		else {
			out.println("you are not autherized user");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			session.invalidate();
			rd.include(request, response);
			//out.println("testing");
			
			
		}
	}

}
