// Author : Akanksha Shrivastava, Adrija Ghansiyal, Abhijeet Nitin Raut,Hrishita Bhattacharjee
// Purpose : Establish connection with derby db & run queries to fetch/add/modify data

package com.code.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.code.bean.Bug;
import com.code.bean.Project;
import com.code.bean.User;
import com.code.dao.DBUtil;


public class BugTrackDaoImpl implements BugTrackDao {
	static Connection conn;
	static PreparedStatement pgetAllProjects,pgetAllBugs,inserimportedusers,pgetAllDevelopers,pgetAllTesters,pins,pgetUser,pinsNewProject,pupdateProject;
	//preparing queries...
	static {
		conn=DBUtil.getMyConnection();
		try {
			//write preparedStatements here
			
			//to import users from json to db
			inserimportedusers = conn.prepareStatement("insert into usertable values(DEFAULT,?,?,?)");
			//to get the project details based on the user of the team member involved
			pgetAllProjects=conn.prepareStatement("select * from projecttable p join teamtable t on p.projectid=t.projectid where t.userid=?");
			//to display bug details as per its project id
			pgetAllBugs = conn.prepareStatement("select * from bugtable where projectid = ? and status='open'");
			pgetAllDevelopers=conn.prepareStatement("select * from usertable where role='developer' && noOfProjects<=1");
			pgetAllTesters=conn.prepareStatement("select * from usertable where role='tester' && noOfProjects<=2");
			pins=conn.prepareStatement("insert into projecttable values(?,?,?,?,?,?)");
			
			//get all the users coming under a new project
			pgetUser=conn.prepareStatement("select * from usertable  where userid=?");
			//update the no. of projects under a given user
			pupdateProject=conn.prepareStatement("update usertable set noOfProjects=? where userid=?");
			//To insert new project to the teamtable
			pinsNewProject=conn.prepareStatement("insert into teamtable values(?,?)");
			//To update the team
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	// Function to save imported users into database
	@Override
	public int importUsers(List<User> userList) {
		int i = 1;
		for(User user : userList) {
			try {
				inserimportedusers.setString(1, user.getName());
				inserimportedusers.setString(2, user.getEmail());
				inserimportedusers.setString(3, user.getType());
				
				inserimportedusers.addBatch();
				
				if(i % 1000 == 0 || i == userList.size()) {
					int[] result = inserimportedusers.executeBatch();
					return result.length;
				}
				i++;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return 0;
	}

	//Function to fetch projects based on userid	
	@Override
	public List<Project> getAllProjects(int userid) {
		List<Project> projectList=new ArrayList<>();
		try {
			pgetAllProjects.setInt(1, userid);
			ResultSet rs=pgetAllProjects.executeQuery();
			while(rs.next()) {
				Project p=new Project(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getString(5),userid);
				projectList.add(p);
			}
			return projectList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	//Function to list bugs based on userid and projectid
	@Override
	public List<Bug> getAllBugs(int projectid) {
		List<Bug> bugList = new ArrayList<Bug>();
		try {
			pgetAllBugs.setInt(1, projectid);
			ResultSet rs=pgetAllBugs.executeQuery();
			while(rs.next()) {
				Bug bug=new Bug(rs.getInt(1),rs.getString(2),rs.getString(3),projectid,rs.getInt(5),rs.getDate(6),rs.getInt(7),rs.getString(8),rs.getInt(9),rs.getDate(10),rs.getString(11),rs.getString(12));
				bugList.add(bug);
			}
			return bugList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//To get all free employees
	public List<User> getAllEmployees(){
		List<User> userList = new ArrayList<User>();
		try {
			
			ResultSet rs1=pgetAllDevelopers.executeQuery();
			while(rs1.next()) {
				User user=new User(rs1.getInt(1),rs1.getString(2),rs1.getString(3),rs1.getString(4));
				userList.add(user);
			}
			ResultSet rs2=pgetAllDevelopers.executeQuery();
			while(rs2.next()) {
				User user=new User(rs2.getInt(1),rs2.getString(2),rs2.getString(3),rs2.getString(4));
				userList.add(user);
			}
			
			return userList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
		
		//To add a new project
		public boolean addProject(Project p) {
			try {
				pins.setInt(1, p.getProjectId());
				pins.setString(2, p.getProjectName());
				pins.setString(3,p.getDescription());
				pins.setString(4,p.getStartDate());
				pins.setString(5,p.getStatus());
				pins.setInt(6,p.getManagerId());
				int i=pins.executeUpdate();
				if(i>0) {
					return true;
				}
				else {
					return false;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
				
			}
			
			
		}
		
		
	

	@Override
	public void updateNoOfProjects(int[] userIdChecked) {
		/*
		 * for(int i=0;i<checked.length;i++) { pNoOfProjects.setInt(1,checked[i]);
		 * pupdate.setInt(2,p.getQty());
		 */
			for(int id:userIdchecked) {
				pgetUser.setInt(1, id);
				ResultSet rs=pgetUser.executeQuery();
				int numproject=rs.getInt("");
				numproject+=1;
				pupdateProject.setInt(1, numproject);
				pupdateProject.setInt(2, id);
				pupdateProject.executeUpdate();
				
				
				
		}
		
		
	}
	
	//To add users to the team
	public void addUsersToProject(int projectId,int[] userIdChecked) {
		for(int id:userIdChechked) {
			pinsNewProject.setInt(1, projectId);
			pinsNewProject.setInt(2, userIdChecked);
			pinsNewProject.executeUpdate();
		}
		
	}

	
}
