package com.code.exception;

public class UserNotFoundException {

}
